//
//  Beth.h
//  Beth
//
//  Created by Justin Kiang on 1/18/24.
//

#import <Foundation/Foundation.h>

//! Project version number for Beth.
FOUNDATION_EXPORT double BethVersionNumber;

//! Project version string for Beth.
FOUNDATION_EXPORT const unsigned char BethVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Beth/PublicHeader.h>


